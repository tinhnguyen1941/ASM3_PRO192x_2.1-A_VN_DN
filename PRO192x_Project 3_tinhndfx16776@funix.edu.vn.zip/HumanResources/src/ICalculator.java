public  interface ICalculator {
     double calculateSalary();
}